package br.com.api.modavintage.Config;
import org.springframework.boot.autoconfigure.security.servlet.PathRequest; // Importar para recursos estáticos
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.annotation.Order;
import org.springframework.http.HttpMethod;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configurers.AbstractHttpConfigurer; // Para desabilitar CSRF de forma mais moderna
import org.springframework.security.config.annotation.web.configurers.HeadersConfigurer; // Para frameOptions
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;

@Configuration
@EnableWebSecurity
public class SecurityConfig {

    @Bean
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }

    @Bean
    @Order(1) // Adicionar uma ordem para o filtro do H2 console
    public SecurityFilterChain h2ConsoleSecurityFilterChain(HttpSecurity http) throws Exception {
        http
            // Aplicar este filtro apenas para o caminho do H2 Console
            .securityMatcher(PathRequest.toH2Console())
            .authorizeHttpRequests(auth -> auth
                .requestMatchers(PathRequest.toH2Console()).permitAll() // Permitir todas as requisições para o H2 console
            )
            // O H2 console usa frames, então precisamos permitir
            .headers(headers -> headers.frameOptions(HeadersConfigurer.FrameOptionsConfig::sameOrigin))
            // Desabilitar CSRF para o H2 console
            .csrf(AbstractHttpConfigurer::disable); // Forma mais moderna de desabilitar CSRF

        return http.build();
    }

    @Bean
    @Order(2) // O filtro principal da API deve ter uma ordem diferente (maior)
    public SecurityFilterChain apiSecurityFilterChain(HttpSecurity http) throws Exception {
        http
            .csrf(AbstractHttpConfigurer::disable) // Desabilitar CSRF
            .sessionManagement(session -> session.sessionCreationPolicy(SessionCreationPolicy.STATELESS))
            .authorizeHttpRequests(auth -> auth
                .requestMatchers(HttpMethod.POST, "/auth/registrar").permitAll()
                .requestMatchers(HttpMethod.POST, "/auth/login").permitAll()
                .requestMatchers(HttpMethod.GET, "/produtos").permitAll()
                .requestMatchers(HttpMethod.GET, "/produtos/**").permitAll()
                // Adicione outras permissões públicas aqui se necessário
                .anyRequest().authenticated() // Todas as outras requisições exigem autenticação
            );
        // filtro JWT será adicionado aqui

        return http.build();
    }
}