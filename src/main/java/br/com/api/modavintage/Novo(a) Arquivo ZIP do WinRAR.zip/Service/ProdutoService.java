package br.com.api.modavintage.Service;

import br.com.api.modavintage.Model.Produto;
import br.com.api.modavintage.Repository.ProdutoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional; // Adicionado

import java.util.Date; // Adicionado
import java.util.List;
import java.util.Optional;

@Service
public class ProdutoService {

    @Autowired
    private ProdutoRepository produtoRepository;

    public Produto salvarProduto(Produto produto) {
        // Se o dataCadastro deve ser definido na criação
        if (produto.getId() == null) { // Novo produto
            produto.setDataCadastro(new Date());
        }
        return produtoRepository.save(produto);
    }

    public List<Produto> listarProdutos() {
        return produtoRepository.findAll();
    }

    // Novo método
    public Optional<Produto> buscarPorId(Long id) {
        return produtoRepository.findById(id);
    }

    // Novo método (com lógica de atualização parcial)
    @Transactional
    public Produto atualizarProduto(Long id, Produto produtoDetalhes) {
        Produto produtoExistente = produtoRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Produto não encontrado com id: " + id));

        if (produtoDetalhes.getNome() != null) {
            produtoExistente.setNome(produtoDetalhes.getNome());
        }
        if (produtoDetalhes.getPreco() != null) {
            produtoExistente.setPreco(produtoDetalhes.getPreco());
        }
        if (produtoDetalhes.getEstoque() != null) {
            produtoExistente.setEstoque(produtoDetalhes.getEstoque());
        }
        if (produtoDetalhes.getTamanho() != null) {
            produtoExistente.setTamanho(produtoDetalhes.getTamanho());
        }
        if (produtoDetalhes.getCategoria() != null) {
            produtoExistente.setCategoria(produtoDetalhes.getCategoria());
        }
        // dataCadastro geralmente não é atualizado, mas sim definido na criação.

        return produtoRepository.save(produtoExistente);
    }

    // Novo método
    @Transactional
    public void deletarProduto(Long id) {
        if (!produtoRepository.existsById(id)) {
            throw new RuntimeException("Produto não encontrado com id: " + id);
        }
        produtoRepository.deleteById(id);
    }

    // Se precisar da busca por categoria, adicione o método de volta no repository 
    // public List<Produto> listarPorCategoria(String categoria) {
    //     return produtoRepository.findByCategoria(categoria); // Precisaria criar este método no ProdutoRepository
    // }
}