package br.com.api.modavintage.Service;


import br.com.api.modavintage.Model.Usuario;
import br.com.api.modavintage.Repository.UsuarioRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.User; // Importar User do Spring Security
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.ArrayList; // Para lista de authorities vazia
import java.util.Optional;

@Service
public class UsuarioService implements UserDetailsService { // Implementar UserDetailsService

    @Autowired
    private UsuarioRepository usuarioRepository;

    @Autowired
    private PasswordEncoder passwordEncoder;

    // Método da interface UserDetailsService
    @Override
    public UserDetails loadUserByUsername(String email) throws UsernameNotFoundException {
        Usuario usuario = usuarioRepository.findByEmail(email)
                .orElseThrow(() -> new UsernameNotFoundException("Usuário não encontrado com o email: " + email));

        // Cria um objeto UserDetails do Spring Security
        // O terceiro argumento são as "authorities" (roles/permissions),
        // por enquanto, deixaremos uma lista vazia.
        return new User(usuario.getEmail(), usuario.getSenha(), new ArrayList<>());
    }

    public Usuario cadastrarUsuario(Usuario usuario) {
        if (usuarioRepository.findByEmail(usuario.getEmail()).isPresent()) {
            throw new RuntimeException("Email já cadastrado: " + usuario.getEmail());
        }
        usuario.setSenha(passwordEncoder.encode(usuario.getSenha()));
        return usuarioRepository.save(usuario);
    }

    // O método autenticar pode ser simplificado ou removido se o login for gerenciado
    // pelo AuthenticationManager do Spring Security, que usará o loadUserByUsername.
    // 
    public Optional<Usuario> autenticar(String email, String senhaLogin) {
        Optional<Usuario> usuarioOptional = usuarioRepository.findByEmail(email);
        if (usuarioOptional.isPresent()) {
            Usuario usuarioNoBanco = usuarioOptional.get();
            if (passwordEncoder.matches(senhaLogin, usuarioNoBanco.getSenha())) {
                return usuarioOptional;
            }
        }
        return Optional.empty();
    }

    public Optional<Usuario> buscarPorEmail(String email) {
        return usuarioRepository.findByEmail(email);
    }

    public Optional<Usuario> buscarPorId(Long id) {
        return usuarioRepository.findById(id);
    }
}