package br.com.api.modavintage.Controller;


import br.com.api.modavintage.Model.Usuario;
import br.com.api.modavintage.Service.UsuarioService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Optional;

@RestController
@RequestMapping("/auth")
public class AuthController {

    @Autowired
    private UsuarioService usuarioService;

    // Novo endpoint para registrar usuário
    @PostMapping("/registrar")
    public ResponseEntity<?> registrarUsuario(@RequestBody Usuario usuario) {
        try {
            Usuario novoUsuario = usuarioService.cadastrarUsuario(usuario);
            // Evitar retornar a senha na resposta
            Usuario respostaUsuario = new Usuario(); // Criar um novo objeto para a resposta
            respostaUsuario.setId(novoUsuario.getId());
            respostaUsuario.setEmail(novoUsuario.getEmail());
            return ResponseEntity.status(HttpStatus.CREATED).body(respostaUsuario);
        } catch (RuntimeException e) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(e.getMessage());
        }
    }

    @PostMapping("/login")
    public ResponseEntity<?> login(@RequestBody Usuario usuarioLogin) { // DTO seria melhor aqui
        Optional<Usuario> usuarioAutenticado = usuarioService.autenticar(usuarioLogin.getEmail(), usuarioLogin.getSenha());

        if (usuarioAutenticado.isPresent()) {
            // Criar um token JWT aqui.
            // 
            Usuario usuario = usuarioAutenticado.get();
            Usuario respostaUsuario = new Usuario();
            respostaUsuario.setId(usuario.getId());
            respostaUsuario.setEmail(usuario.getEmail());
            // 
            return ResponseEntity.ok(respostaUsuario);
        } else {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Email ou senha inválidos.");
        }
    }
}