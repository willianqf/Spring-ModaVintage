package br.com.api.modavintage.dto; // Seu pacote DTO

public class ResetarSenhaDTO {
    private String token;
    private String novaSenha;

    // Getters e Setters
    public String getToken() {
        return token;
    }

    public void setToken(String token) {
        this.token = token;
    }

    public String getNovaSenha() {
        return novaSenha;
    }

    public void setNovaSenha(String novaSenha) {
        this.novaSenha = novaSenha;
    }
}