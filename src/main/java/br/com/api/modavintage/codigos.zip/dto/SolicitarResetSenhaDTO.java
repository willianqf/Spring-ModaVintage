package br.com.api.modavintage.dto; // 

public class SolicitarResetSenhaDTO {
    private String email;

    // Getters e Setters 
    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }
}